import 'package:flutter/material.dart';

class ManagePrinterPage extends StatelessWidget {
  const ManagePrinterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}