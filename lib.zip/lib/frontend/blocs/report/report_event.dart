part of 'report_bloc.dart';

sealed class ReportEvent {}
