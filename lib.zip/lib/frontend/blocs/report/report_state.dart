part of 'report_bloc.dart';

sealed class ReportState {}

final class ReportInitial extends ReportState {}
